/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import javafx.application.Application;;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Rafael
 */
public class Cruzadinha1 extends Application {
    private static Stage fechar;
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/View/Cruzadinha1.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        Cruzadinha1.fechar = stage;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    public static Stage getStage() {
        return Cruzadinha1.fechar;
    }

    public void setStage(Stage s) {
        Cruzadinha1.fechar = s;
    }
}
