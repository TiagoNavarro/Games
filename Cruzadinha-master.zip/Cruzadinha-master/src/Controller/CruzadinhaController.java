/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Main.Cruzadinha;
import Main.Cruzadinha1;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;


/**
 *
 * @author Rafael
 */
public class CruzadinhaController implements Initializable {
    
    @FXML
    private Button idjogar;
    
   
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       idjogar.setOnMouseClicked((MouseEvent e)->{
       Cruzadinha1 tela1 = new Cruzadinha1();
        try {
            tela1.start(new Stage());
            Cruzadinha.getStage().close();
        } catch (Exception ex) {
            Logger.getLogger(CruzadinhaController.class.getName()).log(Level.SEVERE, null, ex);
        }
       });
    }    
    
}
