/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Main.Cruzadinha2;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.effect.BlendMode;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author Rafael
 */
public class Cruzadinha2Controller implements Initializable {

    @FXML
    private Button idpronto;
    @FXML
    private Button idTerminar;
    @FXML
    private TextField idPanela_p;
    @FXML
    private TextField idPanela_a;
    @FXML
    private TextField idPanela_n;
    @FXML
    private TextField idPanela_e;
    @FXML
    private TextField idPanela_l;
    @FXML
    private TextField idPanela_a2;
    @FXML
    private TextField idBone_b;
    @FXML
    private TextField idBone_o;
    @FXML
    private TextField idBone_n;
    @FXML
    private TextField idBone_e;
    @FXML
    private TextField idBola_b;
    @FXML
    private TextField idBola_o;
    @FXML
    private TextField idBola_l;
    @FXML
    private TextField idBola_a;
    @FXML
    private TextField idPiano_p;
    @FXML
    private TextField idPiano_i;
    @FXML
    private TextField idPiano_n;
    @FXML
    private TextField idBebe_e;
    @FXML
    private TextField idBebe_b;
    @FXML
    private TextField idBebe_e2;
    @FXML
    private TextField idBoi_o;
    @FXML
    private TextField idBoi_i;
    @FXML
    private TextField idBoia_b;
    @FXML
    private TextField idBoia_o;
    @FXML
    private TextField idBoia_i;
    @FXML
    private TextField idPiao_i;
    @FXML
    private TextField idPiao_a;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        idpronto.setOnMouseClicked((MouseEvent e) -> {
            String Panela_p = idPanela_p.getText();
            String Panela_a = idPanela_a.getText();
            String Panela_n = idPanela_n.getText();
            String Panela_e = idPanela_e.getText();
            String Panela_l = idPanela_l.getText();
            String Panela_a2 = idPanela_a2.getText();
            String Bone_b = idBone_b.getText();
            String Bone_o = idBone_o.getText();
            String Bone_n = idBone_n.getText();
            String Bone_e = idBone_e.getText();
            String Bola_b = idBola_b.getText();
            String Bola_o = idBola_o.getText();
            String Bola_l = idBola_l.getText();
            String Bola_a = idBola_a.getText();
            String Piano_p = idPiano_p.getText();
            String Piano_i = idPiano_i.getText();
            String Piano_n = idPiano_n.getText();
            String Bebe_e = idBebe_e.getText();
            String Bebe_b = idBebe_b.getText();
            String Bebe_e2 = idBebe_e2.getText();
            String Boi_o = idBoi_o.getText();
            String Boi_i = idBoi_i.getText();
            String Boia_b = idBoia_b.getText();
            String Boia_o = idBoia_o.getText();
            String Boia_i = idBoia_i.getText();
            String Piao_i = idPiao_i.getText();
            String Piao_a = idPiao_a.getText();

            if (Panela_p.equals("p") || Panela_p.equals("P")) {
                idPanela_p.setBlendMode(BlendMode.DIFFERENCE);
               
            }
            if (Panela_a.equals("a") || Panela_a.equals("A")) {
                idPanela_a.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Panela_n.equals("n") || Panela_n.equals("N")) {
                idPanela_n.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Panela_l.equals("l") || Panela_l.equals("L")) {
                idPanela_l.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Panela_a2.equals("a") || Panela_a2.equals("A")) {
                idPanela_a2.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Bone_b.equals("b") || Bone_b.equals("B")) {
                idBone_b.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Bone_o.equals("o") || Bone_o.equals("O")) {
                idBone_o.setBlendMode(BlendMode.DIFFERENCE);
               
            }
            if (Bone_n.equals("n") || Bone_n.equals("N")) {
                idBone_n.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Bone_e.equals("e") || Bone_e.equals("E")) {
                idBone_e.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Bola_b.equals("b") || Bola_b.equals("B")) {
                idBola_b.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Bola_o.equals("o") || Bola_o.equals("O")) {
                idBola_o.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Bola_l.equals("l") || Bola_l.equals("L")) {
                idBola_l.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Bola_a.equals("a") || Bola_a.equals("A")) {
                idBola_a.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Piano_p.equals("p") || Piano_p.equals("P")) {
                idPiano_p.setBlendMode(BlendMode.DIFFERENCE);
               
            }
            if (Piano_i.equals("i") || Piano_i.equals("I")) {
                idPiano_i.setBlendMode(BlendMode.DIFFERENCE);
               
            }
            if (Piano_n.equals("N") || Piano_n.equals("n")) {
                idPiano_n.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Bebe_e.equals("e") || Bebe_e.equals("E")) {
                idBebe_e.setBlendMode(BlendMode.DIFFERENCE);
              
            }
            if (Bebe_b.equals("B") || Bebe_b.equals("b")) {
                idBebe_b.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Bebe_e2.equals("e") || Bebe_e.equals("E")) {
                idBebe_e2.setBlendMode(BlendMode.DIFFERENCE);
               
            }
            if (Boi_o.equals("o") || Boi_o.equals("O")) {
                idBoi_o.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Boi_i.equals("i") || Boi_i.equals("I")) {
                idBoi_i.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Boia_b.equals("b") || Boia_b.equals("B")) {
                idBoia_b.setBlendMode(BlendMode.DIFFERENCE);
               
            }
            if (Boia_o.equals("o") || Boia_o.equals("O")) {
                idBoia_o.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Boia_i.equals("i") || Boia_i.equals("I")) {
                idBoia_i.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Piao_i.equals("i") || Piao_i.equals("I")) {
                idPiao_i.setBlendMode(BlendMode.DIFFERENCE);
               
            }
            if (Piao_a.equals("a") || Piao_a.equals("A")) {
                idPiao_a.setBlendMode(BlendMode.DIFFERENCE);
                
            }
        });
        idTerminar.setOnMouseClicked((MouseEvent e) -> {
            Alert alerta = new Alert(Alert.AlertType.CONFIRMATION);
            alerta.setTitle("Obrigado");
            alerta.setHeaderText("Obrigado por jogar");
            alerta.show();
            Cruzadinha2.getStage().close();
            
        });
    }

}
