/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Main.Cruzadinha;
import Main.Cruzadinha1;
import Main.Cruzadinha2;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.effect.BlendMode;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Rafael
 */
public class Cruzadinha1Controller implements Initializable {

    @FXML
    private TextField idBoneca_B;
    @FXML
    private TextField idBoneca_o;
    @FXML
    private TextField idBoneca_n;
    @FXML
    private TextField idBoneca_e;
    @FXML
    private TextField idBoneca_c;
    @FXML
    private TextField idBoneca_a;
    @FXML
    private TextField idAnel_n;
    @FXML
    private TextField idAnel_e;
    @FXML
    private TextField idRei_e;
    @FXML
    private TextField idRei_i;
    @FXML
    private TextField idBaleia_a;
    @FXML
    private TextField idBaleia_l;
    @FXML
    private TextField idBaleia_i;
    @FXML
    private TextField idBaleia_a2;
    @FXML
    private Button idpronto;
    @FXML
    private Button idproximo;
    static int pontos =0;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        idpronto.setOnMouseClicked((MouseEvent e) -> {
            String b = idBoneca_B.getText();
            String o = idBoneca_o.getText();
            String n = idBoneca_n.getText();
            String boneca_e = idBoneca_e.getText();
            String c = idBoneca_c.getText();
            String a = idBoneca_a.getText();
            String Anel_e = idAnel_e.getText();
            String Anel_n = idAnel_n.getText();
            String Rei_e = idRei_e.getText();
            String Rei_i = idRei_i.getText();
            String Baleia_a = idBaleia_a.getText();
            String Baleia_l = idBaleia_l.getText();
            String Baleia_i = idBaleia_i.getText();
            String Baleia_a2 = idBaleia_a2.getText();
            int pontos =0;

            if (b.equals("b") || b.equals("B")) {
                idBoneca_B.setBlendMode(BlendMode.DIFFERENCE);
               
            }
            if (o.equals("o") || o.equals("O")) {
                idBoneca_o.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (n.equals("n") || n.equals("N")) {
                idBoneca_n.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (boneca_e.equals("e") || boneca_e.equals("E")) {
                idBoneca_e.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (c.equals("c") || c.equals("C")) {
                idBoneca_c.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (a.equals("a") || a.equals("A")) {
                idBoneca_a.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Anel_e.equals("e") || Anel_e.equals("E")) {
                idAnel_e.setBlendMode(BlendMode.DIFFERENCE);
               
            }
            if (Anel_n.equals("n") || Anel_n.equals("N")) {
                idAnel_n.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Rei_e.equals("e") || Rei_e.equals("E")) {
                idRei_e.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Rei_i.equals("i") || Rei_i.equals("I")) {
                idRei_i.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Baleia_a.equals("a") || Baleia_a.equals("A")) {
                idBaleia_a.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Baleia_l.equals("l") || Baleia_l.equals("L")) {
                idBaleia_l.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Baleia_i.equals("i") || Baleia_i.equals("I")) {
                idBaleia_i.setBlendMode(BlendMode.DIFFERENCE);
                
            }
            if (Baleia_a2.equals("a") || Baleia_a2.equals("A")) {
                idBaleia_a2.setBlendMode(BlendMode.DIFFERENCE);
                    
            }
        });
        idproximo.setOnMouseClicked((MouseEvent e) -> {
            Cruzadinha2 tela2 = new Cruzadinha2();
            try {
                tela2.start(new Stage());
                Cruzadinha1.getStage().close();
            } catch (Exception ex) {
                Logger.getLogger(Cruzadinha1Controller.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }

}
